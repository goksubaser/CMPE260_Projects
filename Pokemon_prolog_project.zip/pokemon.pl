%goksu baser
%2016400045
%compiling: yes
%complete: yes
:- [pokemon_data].

% find_pokemon_evolution(+PokemonLevel, +Pokemon, -EvolvedPokemon)
find_pokemon_evolution(PokemonLevel,Pokemon,EvolvedPokemon):-
	% finds final pokemon evolutions according to the level recursively
	pokemon_evolution(Pokemon,EvolvedTempPokemon,Minlvl),
	(PokemonLevel>=Minlvl,
	find_pokemon_evolution(PokemonLevel,EvolvedTempPokemon,EvolvedPokemon);
	PokemonLevel<Minlvl,
	EvolvedPokemon=Pokemon);
	pokemon_stats(Pokemon,_,_,_,_),
	\+pokemon_evolution(Pokemon,EvolvedPokemon,Minlvl),
	EvolvedPokemon=Pokemon.

pokemon_level_stats(PokemonLevel, Pokemon, PokemonHp, PokemonAttack, PokemonDefense):-
	%generates pokemon stats
	pokemon_stats(Pokemon,_,Health,Attack,Defense),
	PokemonHp is PokemonLevel*2+Health,
	PokemonAttack is PokemonLevel+Attack,
	PokemonDefense is PokemonLevel+Defense.


single_type_multiplier(AttackerType,DefenderType,Multiplier):-
	%finds single type multiplier recursively
	type_chart_attack(AttackerType,X),
	pokemon_types(Y),
	recursion2(X,Y,DefenderType,Multiplier).
recursion2([H1|T1],[H2|T2],DefenderType,Multiplier):-
	%if defender type or multiplier found equal, equalize other else repeat with tail list
	((DefenderType = H2,!,
	Multiplier = H1);

	(\+DefenderType = H2;
	\+Multiplier = H1),!,
	recursion2(T1,T2,DefenderType,Multiplier)).



type_multiplier(AttackerType,X, Multiplier):-
	%if list has 1 element return single type multiplier else finds for two types and returns the multiplication result
	length(X,1),
	(X=[H],
	single_type_multiplier(AttackerType,H,Multiplier));
	length(X,2),
	type_multiplier_2(AttackerType,X,Multiplier,Multiplier1,Multiplier2).
type_multiplier_2(AttackerType,X,Multiplier,Multiplier1,Multiplier2):-
	%recursion for type multiplier
	(\+X = [H|T],
	Multiplier is Multiplier1*Multiplier2;

	X = [H|T],
	single_type_multiplier(AttackerType,H,Multiplier1),
	type_multiplier_2(AttackerType,T,Multiplier,Multiplier2,Multiplier1)).

pokemon_type_multiplier(AttackerPokemon, DefenderPokemon, Multiplier):-
	%if AttackerPokemon has two types finds type multiplier for both and returns higher one else returns only one
	pokemon_stats(AttackerPokemon,X,_,_,_),
	pokemon_stats(DefenderPokemon,Y,_,_,_),
	((length(X,1),
	[H]=X,
	type_multiplier(H,Y,Multiplier));

	(length(X,2),
	[H|T]=X,
	[Z]=T,
	type_multiplier(H,Y,Multiplier1),
	type_multiplier(Z,Y,Multiplier2),
	(Multiplier is Multiplier1,Multiplier1>=Multiplier2;
	Multiplier is Multiplier2,Multiplier1<Multiplier2))).

pokemon_attack(AttackerPokemon,AttackerPokemonLevel,DefenderPokemon,DefenderPokemonLevel,Damage):-
	%calculates Damege
	pokemon_level_stats(AttackerPokemonLevel,AttackerPokemon,_,AttackerPokemonAttack,_),
	pokemon_level_stats(DefenderPokemonLevel,DefenderPokemon,_,_,DefenderPokemonDefense),
	pokemon_type_multiplier(AttackerPokemon,DefenderPokemon,Multiplier),
	Damage is 0.5*AttackerPokemonLevel*(AttackerPokemonAttack/DefenderPokemonDefense)*Multiplier+1.

pokemon_fight(Pokemon1,Pokemon1Level,Pokemon2,Pokemon2Level,Pokemon1Hp,Pokemon2Hp,Rounds):-
	%calculates remaining healths of pokemons according to the rounds
	pokemon_attack(Pokemon1,Pokemon1Level,Pokemon2,Pokemon2Level,Damage1),
	pokemon_attack(Pokemon2,Pokemon2Level,Pokemon1,Pokemon1Level,Damage2),
	pokemon_level_stats(Pokemon1Level,Pokemon1,Pokemon1HpBegin,_,_),
	pokemon_level_stats(Pokemon2Level,Pokemon2,Pokemon2HpBegin,_,_),
	round(Pokemon1HpBegin,Pokemon2HpBegin,Damage1,Damage2,RoundsRec),
	Rounds is RoundsRec,
	Pokemon1Hp is Pokemon1HpBegin-(Damage2*Rounds),
	Pokemon2Hp is Pokemon2HpBegin-(Damage1*Rounds).
round(Pokemon1HpBegin,Pokemon2HpBegin,Damage1,Damage2,RoundsRec):-
	%calculates rounds recursively unlit one pokemon dies(hp<0) and returns rounds
	\+Pokemon1HpBegin=<0,
	\+Pokemon2HpBegin=<0,
	Pokemon1HpTemp is Pokemon1HpBegin-Damage2,
	Pokemon2HpTemp is Pokemon2HpBegin-Damage1,
	round(Pokemon1HpTemp,Pokemon2HpTemp,Damage1,Damage2,RoundsRec2),
	RoundsRec is RoundsRec2+1,!;

	(Pokemon1HpBegin=<0;Pokemon2HpBegin=<0),
	RoundsRec is 0.
pokemon_tournament(PokemonTrainer1, PokemonTrainer2,WinnerTrainerList):-
	%finds evolved version pokemons of trainers and fights them with pokemon_fight one by one recursively
	pokemon_trainer(PokemonTrainer1,PokemonList1,PokemonLevelList1),
	find_listof_evolved_pokemons(PokemonList1,PokemonLevelList1,PokemonEvolvedList1,T1),
	pokemon_trainer(PokemonTrainer2,PokemonList2,PokemonLevelList2),
	find_listof_evolved_pokemons(PokemonList2,PokemonLevelList2,PokemonEvolvedList2,T2),
	pokemon_list_fight(PokemonEvolvedList1,PokemonLevelList1,PokemonEvolvedList2,PokemonLevelList2,PokemonTrainer1,PokemonTrainer2,WinnerTrainerList,WinnerTrainerListTemp),!.
find_listof_evolved_pokemons(PokemonList,PokemonLevelList,PokemonEvolvedList,PokemonEvolvedListTemp):-
	%finds evolved versions of pokemons of trainers recursively
	\+length(PokemonList,1),
	PokemonList = [H1|T1],
	PokemonLevelList = [H2|T2],
	find_pokemon_evolution(H2,H1,EvolvedPokemon),
	append(PokemonEvolvedListTemp,[EvolvedPokemon],PokemonEvolvedListTemp1),
	find_listof_evolved_pokemons(T1,T2,PokemonEvolvedList,PokemonEvolvedListTemp1);

	length(PokemonList,1),
	PokemonList = [H1],
	PokemonLevelList = [H2],
	find_pokemon_evolution(H2,H1,EvolvedPokemon),
	append(PokemonEvolvedListTemp,[EvolvedPokemon],PokemonEvolvedListTemp1),
	PokemonEvolvedList = PokemonEvolvedListTemp1.
pokemon_list_fight(PokemonEvolvedList1,PokemonLevelList1,PokemonEvolvedList2,PokemonLevelList2,PokemonTrainer1,PokemonTrainer2,WinnerTrainerList,WinnerTrainerListTemp):-
	%recursively fights pokemons one by one
	\+length(PokemonEvolvedList1,1),
	PokemonEvolvedList1=[H1|T1],
	PokemonLevelList1=[H2|T2],
	PokemonEvolvedList2=[H3|T3],
	PokemonLevelList2=[H4|T4],
	pokemon_fight(H1,H2,H3,H4,Pokemon1Hp,Pokemon2Hp,Rounds),
	(Pokemon1Hp>=Pokemon2Hp,
	append(WinnerTrainerListTemp,[PokemonTrainer1],WinnerTrainerListTemp2);
	Pokemon1Hp<Pokemon2Hp,
	append(WinnerTrainerListTemp,[PokemonTrainer2],WinnerTrainerListTemp2)),
	pokemon_list_fight(T1,T2,T3,T4,PokemonTrainer1,PokemonTrainer2,WinnerTrainerList,WinnerTrainerListTemp2);

	length(PokemonEvolvedList1,1),
	PokemonEvolvedList1=[H1],
	PokemonLevelList1=[H2],
	PokemonEvolvedList2=[H3],
	PokemonLevelList2=[H4],
	pokemon_fight(H1,H2,H3,H4,Pokemon1Hp,Pokemon2Hp,Rounds),
	(Pokemon1Hp>=Pokemon2Hp,
	append(WinnerTrainerListTemp,[PokemonTrainer1],WinnerTrainerListTemp2);
	Pokemon1Hp<Pokemon2Hp,
	append(WinnerTrainerListTemp,[PokemonTrainer2],WinnerTrainerListTemp2)),
	WinnerTrainerList = WinnerTrainerListTemp2.

best_pokemon(EnemyPokemon,LevelCap,RemainingHp,BestPokemon):-
	%finds best pokemon for given EnemyPokemon according to the remaining healh after pokemon fight
	findall(Pokemon,pokemon_stats(Pokemon,_,_,_,_),PokemonList),
	findall(RemainingHp,pokemon_fight(Pokemon1,LevelCap,EnemyPokemon,LevelCap,RemainingHp,_,_),RemainingHpList),
	list_merger(PokemonList,RemainingHpList,MergedList,Temp1),!,
	sort(MergedList,SortedList1),
	reverse(SortedList1,SortedList),
	SortedList=[H|T],
	H=[H1|T1],
	RemainingHp=H1,
	[T2]=T1,
	BestPokemon=T2.
list_merger(PokemonList,RemainingHpList,MergedList,Temp1):-
	%merges two listes into one nested list [a,b]+[c,d]=[[a,c],[b,d]]
	\+length(PokemonList,1),
	PokemonList=[H1|T1],
	RemainingHpList = [H2|T2],
	append([H2],[H1],Temp3),
	append(Temp1,[Temp3],Temp2),
	list_merger(T1,T2,MergedList,Temp2);

	length(PokemonList,1),
	PokemonList=[H1],
	RemainingHpList=[H2],
	append([H2],[H1],Temp3),
	append(Temp1,[Temp3],Temp2),
	MergedList = Temp2.

best_pokemon_team(OppenentTrainer,PokemonTeam):-
	%finds best pokemon team from every pokemon in the knowlage base against enemy trainer's team. Does this via recursion of pokemon_fight on Enemy pokemon list
	pokemon_trainer(OppenentTrainer,OppenentTeam,OppenentTeamLevels),
	best_pokemon_team_recursion(OppenentTeam,OppenentTeamLevels,PokemonTeam,_),!.
best_pokemon_team_recursion(OppenentTeam,OppenentTeamLevels,BestTeam,Temp):-
	%simulates every fight against OppenentTeam for every pokemon and appends the best one then returns the total list
	\+length(OppenentTeam,1),
	OppenentTeam=[H1|T1],
	OppenentTeamLevels=[H2|T2],
	best_pokemon(H1,H2,_,BestPokemon),
	append(Temp,[BestPokemon],Temp2),
	best_pokemon_team_recursion(T1,T2,BestTeam,Temp2);

	length(OppenentTeam,1),
	OppenentTeam=[H1],
	OppenentTeamLevels=[H2],
	best_pokemon(H1,H2,_,BestPokemon),
	append(Temp,[BestPokemon],Temp2),
	BestTeam=Temp2.

pokemon_types(TypeList, InitialPokemonList,PokemonList):-
	%finds pokemons in the pokemon list and has the types of the TypeList
	findall(Pokemon,(member(Pokemon,InitialPokemonList),pokemon_types_2(TypeList,Pokemon)),PokemonList).
pokemon_types_2([H|TypeListTail],Pokemon):-
	pokemon_stats(Pokemon,PokemonTypeList,_,_,_),
	((member(H,PokemonTypeList),!);pokemon_types_2(TypeListTail,Pokemon)).

generate_pokemon_team(LikedTypes,DisLikedTypes,Criterion,Count,PokemonTeam):-
	%from all pokemons finds liked ones via pokemon_types and then substracts DisLiked ones then creates a nested list of pokemon,pokemonhp,pokemonAttack,pokemondefense
	%and does this according to the Criterion (the list begins with criterion field of pokemon) then sortes the list and via list_popper finds first Count pokemons
	%after that corrects list according to the output type wanted.
	findall(Pokemon,pokemon_stats(Pokemon,_,_,_,_),PokemonList),
	pokemon_types(LikedTypes,PokemonList,LikedPokemonList),
	pokemon_types(DisLikedTypes,LikedPokemonList,DisLikedPokemonList),
	subtract(LikedPokemonList,DisLikedPokemonList,ValidPokemonList),

	(Criterion = a,
	findall([Attack,Hp,ValidPokemon,Defense],(member(ValidPokemon,ValidPokemonList),pokemon_stats(ValidPokemon,_,Hp,Attack,Defense)),ListofValidPokemonStats);
	Criterion = h,
	findall([Hp,ValidPokemon,Attack,Defense],(member(ValidPokemon,ValidPokemonList),pokemon_stats(ValidPokemon,_,Hp,Attack,Defense)),ListofValidPokemonStats);
	Criterion = d,
	findall([Defense,Hp,Attack,ValidPokemon],(member(ValidPokemon,ValidPokemonList),pokemon_stats(ValidPokemon,_,Hp,Attack,Defense)),ListofValidPokemonStats)),

	sort(ListofValidPokemonStats,ListofValidPokemonStatsSorted1),
	reverse(ListofValidPokemonStatsSorted1,ListofValidPokemonStatsSorted),
	list_popper(ListofValidPokemonStatsSorted,Count,ListofValidPokemonStatsSortedShort,_),!,
	(Criterion = a,
	findall([X,Y,Z,T],(member([Z,Y,X,T],ListofValidPokemonStatsSortedShort)),PokemonTeam);
	Criterion = h,
	findall([X,Y,Z,T],(member([Y,X,Z,T],ListofValidPokemonStatsSortedShort)),PokemonTeam);
	Criterion = d,
	findall([X,Y,Z,T],(member([T,Y,Z,X],ListofValidPokemonStatsSortedShort)),PokemonTeam)),!.
list_popper(ListofValidPokemonStatsSorted,Count,ListofValidPokemonStatsSortedShort,Temp):-
	%finds first Count elements of a list
	Count>1,
	ListofValidPokemonStatsSorted=[H|T],
	append(Temp,[H],Temp2),
	CountTemp is Count-1,
	list_popper(T,CountTemp,ListofValidPokemonStatsSortedShort,Temp2);
	
	\+  Count > 1,
	ListofValidPokemonStatsSorted=[H|T],
	append(Temp,[H],Temp2),
	ListofValidPokemonStatsSortedShort=Temp2.